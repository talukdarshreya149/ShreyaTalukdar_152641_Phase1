package com.cg.mypaymentapp.dao;

import java.util.ArrayList;
import java.util.Map;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;

public interface WalletDao {

	public String save(Customer customer);
	public Customer findOne(String mobileNo);
	public boolean checkMobile(String mobileNo);
	public void addTransactions(String transaction);
	public ArrayList<String> printTransactions() throws InvalidInputException;
}
