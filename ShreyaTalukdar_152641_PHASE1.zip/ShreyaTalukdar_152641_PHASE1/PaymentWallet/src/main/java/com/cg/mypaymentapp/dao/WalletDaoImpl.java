package com.cg.mypaymentapp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.InvalidInputException;



public class WalletDaoImpl implements WalletDao {
	
	
	private static Map<String, Customer> data=null; 
	private static ArrayList<String> transactions=null;
	
	static {
		data=new HashMap<String, Customer>();
		transactions=new ArrayList<String>();
	}
	
	public String save(Customer customer) {
		
		data.put(customer.getMobileNo(),customer);
		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) {
		
		Customer search=null;
		if(data.containsKey(mobileNo))
		{
			search=data.get(mobileNo);
		}
		return search;
	}

	public boolean checkMobile(String mobileNo) {
		// TODO Auto-generated method stub
		boolean result = false;
		if(data.containsKey(mobileNo)) {
			result=true;
		}
		else {
			result=false;
		}
		return result;
		
	}
  public void addTransactions(String transaction) {
	 transactions.add(transaction);
   }

  public ArrayList<String> printTransactions() throws InvalidInputException {
		// TODO Auto-generated method stub
		return transactions;
	}


	

}

