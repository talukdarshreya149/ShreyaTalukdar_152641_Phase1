package com.cg.mypaymentapp.exception;

public interface IInvalidInputException {
String ERROR1="Invalid MobileNo";
String ERROR2="Invalid Name";
}
