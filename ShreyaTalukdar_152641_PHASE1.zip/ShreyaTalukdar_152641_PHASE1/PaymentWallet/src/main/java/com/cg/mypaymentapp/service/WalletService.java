package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public interface WalletService {
	
	public void createAccount(Customer customer);
	public Customer showBalance (String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount);
	public Customer depositAmount (String mobileNo,BigDecimal amount );
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
    public ArrayList<String> printTransactions() throws InvalidInputException;
	public boolean inputValidation(String name, String mobileNo) throws InvalidInputException;
    public boolean balanceValidation(BigDecimal amount, String mobNo )throws InsufficientBalanceException;
    public boolean mobileValidation(String mobile) throws InvalidInputException;
    public boolean transferValidation(BigDecimal amount, String mobNoS) throws InsufficientBalanceException;
   public boolean checkMobile(String mobileNo);
}