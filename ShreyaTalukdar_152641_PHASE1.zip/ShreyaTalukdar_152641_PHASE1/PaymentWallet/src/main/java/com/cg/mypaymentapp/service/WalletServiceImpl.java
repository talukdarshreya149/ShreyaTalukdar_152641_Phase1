package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.imageio.metadata.IIOInvalidTreeException;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.dao.WalletDao;
import com.cg.mypaymentapp.dao.WalletDaoImpl;
import com.cg.mypaymentapp.exception.IInsufficientbalanceException;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletServiceImpl implements WalletService {
	
private WalletDao dao=null;
	
	public WalletServiceImpl(){
		dao= new  WalletDaoImpl();
	}
	

	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		dao.save(customer);
	}



	

	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		return dao.findOne(mobileno);
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Customer customerDetails2=dao.findOne(sourceMobileNo);
		BigDecimal senderBal=customerDetails2.getWallet();
		senderBal=senderBal.subtract(amount);
		customerDetails2.setWallet(senderBal);
		
		Customer customerDetails3=dao.findOne(sourceMobileNo);
		BigDecimal receiverbal=customerDetails3.getWallet();
		receiverbal=receiverbal.add(amount);
		customerDetails3.setWallet(receiverbal);	
		return customerDetails2;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Customer customerDetails=dao.findOne(mobileNo);
		
		BigDecimal finalAmt=customerDetails.getWallet().add(amount);
		customerDetails.setWallet(finalAmt);
		return customerDetails;
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Customer customerDetails1=dao.findOne(mobileNo);
		BigDecimal finalAmt1=customerDetails1.getWallet().subtract(amount);
		customerDetails1.setWallet(finalAmt1);
		return customerDetails1;
		
	}
	
   public ArrayList<String> printTransactions() throws InvalidInputException {
		
		return dao.printTransactions();
	}
	

	public boolean inputValidation(String name, String mobileNo) throws InvalidInputException {
		// TODO Auto-generated method stub
		boolean result=false;
		if(name.trim().matches("^[A-Z a-z]*$")) {
			if(mobileNo.length()==10) {
				result=true;
			}else {
				throw new InvalidInputException(IInvalidInputException.ERROR1);
			}
		}else {
			throw new InvalidInputException(IInvalidInputException.ERROR2);
		}
		return result;
	}


	public boolean balanceValidation(BigDecimal amount, String mobNo) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		boolean result=false;
		BigDecimal balance=dao.findOne(mobNo).getWallet();
		if(amount.compareTo(balance)==-1) {
			result=true;
			
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR1);
		}
		return result;
	}


	public boolean mobileValidation(String mobile) throws InvalidInputException {
		// TODO Auto-generated method stub
		 boolean result=false;
		 if(mobile.length()==10) {
			 result=true;
			 
		 } else {
			 throw  new InvalidInputException(IInvalidInputException.ERROR1);
		 }
		 
		 return result;
	}


	public boolean transferValidation(BigDecimal amount, String mobNoS) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		boolean result=false;
		BigDecimal bal1=dao.findOne(mobNoS).getWallet();
		if(amount.compareTo(bal1)==-1) {
			result=true;
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR2);
		}
		return result;
	}


	public boolean checkMobile(String mobileNo) {
		// TODO Auto-generated method stub
		return dao.checkMobile(mobileNo);
	}





	
}
